/**
@file scorewidget.h
@brief Plik nagłówkowy klasy ScoreWidget - widgeta wyświetlającego wynik i przycisk zmiany języka.
*/

#ifndef SCOREWIDGET_H
#define SCOREWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QHBoxLayout>
#include <QTimer>
#include <QPushButton>

class ScoreWidget : public QWidget {
    Q_OBJECT
signals:
    void changeLang();
public:
    /**
    * @brief Konstruktor klasy ScoreWidget.
    *
    * Konstruktor konfiguruje wyświetlanie przycisku zmiany języka i aktualnego wyniku.
    *
    * @param parent Wskaźnik na obiekt rodzica, domyślnie nullptr.
    */
    ScoreWidget(QWidget *parent = nullptr);
    /**
    * @brief Metoda displayScore - generuje tekst z wynikiem adekwatnie do wybranego języka.
    *
    */
    void displayScore();
public slots:
    /**
    * @brief Slot readScore - zapisuje aktualny wynik po otrzymaniu sygnału.
    *
    */
    void readScore(int new_score);
    /**
    * @brief Slot updateScore - wyświetla nowy wynik po otrzymaniu sygnału.
    *
    */
    void updateScore();
    /**
    * @brief Slot langButtonPress - zmienia język po otrzymaniu sygnału.
    *
    */
    void langButtonPress();

private:
    int lang = 0; //0 PL 1 ENG
    int score = 0;
    QLabel* scoreLabel;
    QTimer* updateTimer;
    QPushButton* langButton; // Add this line

};


#endif // SCOREWIDGET_H


