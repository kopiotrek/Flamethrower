/**

@file chart.h
@brief Plik nagłówkowy klasy Chart - widgeta wyświetlającego aktualne wskazania akcelerometru
*/

#ifndef CHART_H
#define CHART_H

#include <QWidget>
#include <QVector>
#include <QTimer>
#include <QPaintEvent>
#include <QPainter>

#include <QTime>

class Chart : public QWidget
{
    Q_OBJECT

public:
    /**
    * @brief Konstruktor klasy Chart.
    *
    * Konstruktor tworzy widget i timer.
    *
    * @param parent Wskaźnik na obiekt rodzica, domyślnie nullptr.
    */
    explicit Chart(QWidget *parent = nullptr)
        : QWidget(parent), maxDataPoints(200)
    {
        // Set up the timer to update the widget periodically
        QTimer *timer = new QTimer(this);
        timer->start(100); // Update every 100 milliseconds

        // Initialize the timer to calculate elapsed time
        time.start();
    }

public slots:
    /**
    * @brief Slot axVal.
    *
    * Slot odbiera nową wartość akcelerometru i umieszcza na wykresie.
    *
    * @param int value.
    */
    void axVal(int value)
    {
        // Add the new data point to the plot
        dataPoints.append({time.elapsed() / 1000.0, value});

        // Remove oldest data points if we exceed the maximum number of data points
        while (dataPoints.size() > maxDataPoints && dataPoints.size() > 2)
            dataPoints.pop_front();

        // Update the widget
        update();
    }

protected:
    /**
    * @brief Metoda rysująca.
    *
    * Metoda rysująca, która jest wywoływana za każdym razem, gdy widget wymaga odświeżenia.
    * Wewnątrz funkcji rysującej powstaje wykres.
    *
    * @param event Zdarzenie rysowania, domyślnie nullptr.
    */
    void paintEvent(QPaintEvent *event) override
    {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing, true);

        // Clear the widget
        painter.fillRect(event->rect(), Qt::white);

        // Calculate the scale factors
        int width = event->rect().width();
        int height = event->rect().height();
        double xScale = width / 2.0; // Displaying only last 2 seconds
        double yScale = height / 60000.0; // Adjusted for the range -30000 to +30000

        // Calculate the minimum X value for the range
        double minX = time.elapsed() / 1000.0 - 2;

        // Calculate the y-coordinate for the bottom of the widget
        double yBottom = height - (30000.0 * yScale);

        // Draw the plot
        painter.setPen(Qt::blue);
        int numDataPoints = dataPoints.size();
        for (int i = 1; i < numDataPoints; ++i)
        {
            double x1 = (dataPoints.at(i - 1).first - minX) * xScale;
            double y1 = yBottom - dataPoints.at(i - 1).second * yScale;
            double x2 = (dataPoints.at(i).first - minX) * xScale;
            double y2 = yBottom - dataPoints.at(i).second * yScale;
            painter.drawLine(QPointF(x1, y1), QPointF(x2, y2));
        }
    }

private:
    QVector<QPair<double, int>> dataPoints;
    const int maxDataPoints;
    QTime time;
};


#endif // CHART_H
