/**

@file hint.h
@brief Plik nagłówkowy klasy Hint - widgeta wyświetlającego wskazówkę u dołu ekranu.
*/

#ifndef HINT_H
#define HINT_H


#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>
#include <QWidget>

class Hint : public QWidget
{
    Q_OBJECT

public:
    /**
    * @brief Konstruktor klasy Hint.
    *
    * Konstruktor ustawia formatowanie tekstu i wyświetla wskazówkę.
    *
    * @param parent Wskaźnik na obiekt rodzica, domyślnie nullptr.
    */
    Hint(QWidget *parent = nullptr)
        : QWidget(parent)
    {
        QLabel *label = new QLabel("Wskazówka: Aby sterować miotaczem obracaj padem", this);
        QFont font("Monospace");
        font.setStyleHint(QFont::TypeWriter);
        font.setPixelSize(18);
        font.setLetterSpacing(QFont::PercentageSpacing, 120);  // Increase letter spacing (e.g., 150%)
        font.setItalic(true);  // Set font style to italic
        label->setFont(font);
        label->setStyleSheet("color: #FFFFFF");  // White text color


        QVBoxLayout *layout = new QVBoxLayout(this);
        layout->addWidget(label);

        setLayout(layout);
    }

public slots:
    /**
    * @brief Slot changeLang.
    *
    * Slot po aktywacji przełącza język wskazówki na kolejny.
    *
    */
    void changeLang()
    {
        QLabel *label = findChild<QLabel *>();
        if (label)
        {
            if (label->text() == "Hint: Move your gamepad to rotate the flamethrower")
                label->setText("Wskazówka: Aby sterować miotaczem obracaj padem");
            else
                label->setText("Hint: Move your gamepad to rotate the flamethrower");
        }
    }
};


#endif // HINT_H
