/**

@file mainwindow.h
@brief Plik nagłówkowy klasy MainWindow - głównego okna aplikacji
*/

#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    /**
    * @brief Konstruktor klasy MainWindow.
    *
    * Konstruktor uruchamia główne okno aplikacji na podstawie pliku mainwindow.ui
    *
    * @param parent Wskaźnik na obiekt rodzica, domyślnie nullptr.
    */
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();


private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
