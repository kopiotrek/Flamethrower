#include "scorewidget.h"

ScoreWidget::ScoreWidget(QWidget *parent) : QWidget(parent)
{
    scoreLabel = new QLabel(QString::number(score), this);
    scoreLabel->setAlignment(Qt::AlignCenter);

    langButton = new QPushButton("LANG", this);
    langButton->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed); // Set size policy

    auto layout = new QVBoxLayout(this); // Use vertical layout
    layout->addWidget(scoreLabel);
    layout->addStretch(); // Add stretch to push the button to the bottom
    layout->addWidget(langButton);

    setLayout(layout);

    // Set black background
    QPalette pal = palette();
    pal.setColor(QPalette::Background, Qt::black);
    setAutoFillBackground(true);
    setPalette(pal);

    // Set font and color
    QFont font;
    font.setBold(true);
    font.setItalic(true);
    font.setPointSize(20);
    scoreLabel->setFont(font);
    scoreLabel->setStyleSheet("color: white;");


    updateTimer = new QTimer(this);
    connect(updateTimer, SIGNAL(timeout()), this, SLOT(updateScore()));
    updateTimer->start(100); // Refresh every 1 second

    // Apply stylesheet to the button
    langButton->setStyleSheet("QPushButton {"
                              "background-color: black;"
                              "border: 2px solid white;"
                              "color: white;"
                              "font: bold italic 14px;"
                              "}"
                              "QPushButton:pressed {"
                              "background-color: darkGrey;"
                              "}");

    connect(langButton, SIGNAL(clicked()), this, SLOT(langButtonPress())); // Add this line
}

void ScoreWidget::readScore(int new_score){
    score = new_score;
}

void ScoreWidget::updateScore(){
    displayScore();
}

void ScoreWidget::displayScore(){
    if(lang){
        scoreLabel->setText(QString("Score  \n%1").arg(score));
    }
    else
    {
        scoreLabel->setText(QString("Wynik  \n%1").arg(score));
    }

}

void ScoreWidget::langButtonPress(){
    if(lang)
        lang=0;
    else
        lang=1;
    emit changeLang();
}
