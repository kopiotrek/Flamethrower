var searchData=
[
  ['mywidget_23',['MyWidget',['../classMyWidget.html#a4a9d659321b8e86eef35b115a767a991',1,'MyWidget']]]
];
