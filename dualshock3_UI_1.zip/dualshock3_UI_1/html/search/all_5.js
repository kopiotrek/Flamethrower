var searchData=
[
  ['reader_10',['Reader',['../classReader.html',1,'Reader'],['../classReader.html#ab573574f4e5a420d975c88b459fe6bcf',1,'Reader::Reader()']]],
  ['reader_2eh_11',['reader.h',['../reader_8h.html',1,'']]]
];
