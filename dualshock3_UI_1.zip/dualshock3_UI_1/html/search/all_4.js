var searchData=
[
  ['paintevent_9',['paintEvent',['../classMyWidget.html#ab35db698cabbe26a8408e6cf0bc5597b',1,'MyWidget']]]
];
