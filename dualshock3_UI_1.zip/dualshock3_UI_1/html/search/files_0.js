var searchData=
[
  ['mywidget_2ecpp_15',['mywidget.cpp',['../mywidget_8cpp.html',1,'']]],
  ['mywidget_2eh_16',['mywidget.h',['../mywidget_8h.html',1,'']]]
];
