var searchData=
[
  ['handleread_21',['handleRead',['../classReader.html#a360a128a4c66a5581d62160630c7039b',1,'Reader']]]
];
