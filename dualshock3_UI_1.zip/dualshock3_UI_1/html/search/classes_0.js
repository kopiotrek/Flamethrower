var searchData=
[
  ['mainwindow_12',['MainWindow',['../classMainWindow.html',1,'']]],
  ['mywidget_13',['MyWidget',['../classMyWidget.html',1,'']]]
];
