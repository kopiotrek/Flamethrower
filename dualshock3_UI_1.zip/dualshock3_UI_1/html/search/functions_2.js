var searchData=
[
  ['interpretserial_22',['interpretSerial',['../classReader.html#a9ab3e3f3e65f2ba6b0915e4648dfe662',1,'Reader']]]
];
