var searchData=
[
  ['mainwindow_5',['MainWindow',['../classMainWindow.html',1,'']]],
  ['mywidget_6',['MyWidget',['../classMyWidget.html',1,'MyWidget'],['../classMyWidget.html#a4a9d659321b8e86eef35b115a767a991',1,'MyWidget::MyWidget()']]],
  ['mywidget_2ecpp_7',['mywidget.cpp',['../mywidget_8cpp.html',1,'']]],
  ['mywidget_2eh_8',['mywidget.h',['../mywidget_8h.html',1,'']]]
];
