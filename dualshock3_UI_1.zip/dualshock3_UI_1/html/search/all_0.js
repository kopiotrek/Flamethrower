var searchData=
[
  ['getax_0',['getAx',['../classReader.html#a205b493f70b9e67620d31dbb8d75d8eb',1,'Reader']]],
  ['getay_1',['getAy',['../classReader.html#a67c2b1f4e0713f7c4171cb099da54e62',1,'Reader']]],
  ['getaz_2',['getAz',['../classReader.html#a1bc5a34e6169f47c70cba5ca562ada22',1,'Reader']]]
];
