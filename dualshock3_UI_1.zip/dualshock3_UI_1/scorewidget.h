#ifndef SCOREWIDGET_H
#define SCOREWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QHBoxLayout>
#include <QTimer>

class ScoreWidget : public QWidget {
    Q_OBJECT
public:
    ScoreWidget(QWidget *parent = nullptr);
    void displayScore();
public slots:
    void readScore(int new_score);
    void updateScore();

private:
    int score = 0;
    QLabel* scoreLabel;
    QTimer* updateTimer;
};


#endif // SCOREWIDGET_H


