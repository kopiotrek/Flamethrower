#ifndef CHART_H
#define CHART_H

#include <QWidget>

class Chart
{
public:
    Chart();
};

#endif // CHART_H
