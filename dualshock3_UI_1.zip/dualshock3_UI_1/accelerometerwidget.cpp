#include <QtWidgets>
#include <QtCharts>
#include "accelerometerwidget.h"

QT_CHARTS_USE_NAMESPACE

class AccelerometerWidget : public QWidget
{
    Q_OBJECT

public:
    explicit AccelerometerWidget(QWidget *parent = nullptr)
        : QWidget(parent)
    {
        // Create a line series for each axis
        m_seriesX = new QLineSeries(this);
        m_seriesY = new QLineSeries(this);
        m_seriesZ = new QLineSeries(this);

        // Create a chart and add the series
        m_chart = new QChart;
        m_chart->addSeries(m_seriesX);
        m_chart->addSeries(m_seriesY);
        m_chart->addSeries(m_seriesZ);
        m_chart->setTitle("Accelerometer Data");

        // Create an X axis and set labels
        QValueAxis *axisX = new QValueAxis;
        axisX->setTitleText("Time");
        axisX->setLabelFormat("%d");
        m_chart->addAxis(axisX, Qt::AlignBottom);
        m_seriesX->attachAxis(axisX);
        m_seriesY->attachAxis(axisX);
        m_seriesZ->attachAxis(axisX);

        // Create a Y axis and set labels
        QValueAxis *axisY = new QValueAxis;
        axisY->setTitleText("Acceleration");
        axisY->setLabelFormat("%.2f");
        m_chart->addAxis(axisY, Qt::AlignLeft);
        m_seriesX->attachAxis(axisY);
        m_seriesY->attachAxis(axisY);
        m_seriesZ->attachAxis(axisY);

        // Create the chart view
        QChartView *chartView = new QChartView(m_chart);
        chartView->setRenderHint(QPainter::Antialiasing);

        // Create a layout for the widget
        QVBoxLayout *layout = new QVBoxLayout;
        layout->addWidget(chartView);
        setLayout(layout);

        // Initialize data
        m_dataCounter = 0;
        m_timerId = startTimer(100); // Update chart every 100 milliseconds
    }

protected:
    void timerEvent(QTimerEvent *event) override
    {
        if (event->timerId() == m_timerId) {
            // Generate random accelerometer data for demonstration
            qreal x = qrand() % 10;
            qreal y = qrand() % 10;
            qreal z = qrand() % 10;

            // Append data to the series
            m_seriesX->append(m_dataCounter, x);
            m_seriesY->append(m_dataCounter, y);
            m_seriesZ->append(m_dataCounter, z);

            // Remove old data points after a certain number of points
            const int maxDataPoints = 100;
            if (m_seriesX->count() > maxDataPoints) {
                m_seriesX->remove(0);
                m_seriesY->remove(0);
                m_seriesZ->remove(0);
                m_chart->axes(Qt::Horizontal).first()->setRange(
                    m_dataCounter - maxDataPoints, m_dataCounter);
            }

            // Update the chart view
            m_chart->axes(Qt::Horizontal).first()->setRange(0, m_dataCounter);
            chart()->scroll(chart()->plotArea().width() / maxDataPoints, 0);
            ++m_dataCounter;
        }
    }

private:
    QChart *m_chart;
    QLineSeries *m_seriesX;
    QLineSeries *m_seriesY;
    QLineSeries *
