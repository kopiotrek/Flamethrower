#include "scorewidget.h"

ScoreWidget::ScoreWidget(QWidget *parent) : QWidget(parent)
{
    scoreLabel = new QLabel(QString::number(score), this);
    scoreLabel->setAlignment(Qt::AlignCenter);
    auto layout = new QHBoxLayout(this);
    layout->addWidget(scoreLabel);
    setLayout(layout);

    // Set black background
    QPalette pal = palette();
    pal.setColor(QPalette::Background, Qt::black);
    setAutoFillBackground(true);
    setPalette(pal);

    // Set font and color
    QFont font;
    font.setBold(true);
    font.setItalic(true);
    font.setPointSize(20);
    scoreLabel->setFont(font);
    scoreLabel->setStyleSheet("color: white;");


    updateTimer = new QTimer(this);
    connect(updateTimer, SIGNAL(timeout()), this, SLOT(updateScore()));
    updateTimer->start(1000); // Refresh every 1 second
}

void ScoreWidget::readScore(int new_score){
    score = new_score;
}

void ScoreWidget::updateScore(){
    displayScore();
}

void ScoreWidget::displayScore(){
    scoreLabel->setText(QString(" Score  \n%1").arg(score));
}
