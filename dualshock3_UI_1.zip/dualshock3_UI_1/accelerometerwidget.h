#ifndef ACCELEROMETERWIDGET_H
#define ACCELEROMETERWIDGET_H

#include <QWidget>
#include <QtCharts>

QT_CHARTS_USE_NAMESPACE

class AccelerometerWidget : public QWidget
{
    Q_OBJECT

public:
    explicit AccelerometerWidget(QWidget *parent = nullptr);

protected:
    void timerEvent(QTimerEvent *event) override;

private:
    QChart *m_chart;
    QLineSeries *m_seriesX;
    QLineSeries *m_seriesY;
    QLineSeries *m_seriesZ;
    int m_dataCounter;
    int m_timerId;
};

#endif // ACCELEROMETERWIDGET_H
