#include "chart.h"

Chart::Chart()
{

}
